import React from 'react';
import { motion } from 'motion/react';
import { ExternalLink, Github, Layers, Zap, Database } from 'lucide-react';
import { cn } from '../lib/utils';

const projects = [
  {
    title: 'AI-Powered Workflow Automation Platform',
    description: 'A comprehensive automation suite that leverages LLMs to handle complex business processes, reducing manual intervention by 80%.',
    tech: ['n8n', 'OpenAI', 'LangChain', 'Node.js'],
    impact: 'Reduced manual work by 80%',
    icon: Zap,
    color: 'from-neon-blue to-neon-cyan'
  },
  {
    title: 'Email RAG System',
    description: 'An intelligent email processing system that uses Retrieval Augmented Generation to provide context-aware responses and categorization.',
    tech: ['Python', 'Pinecone', 'OpenAI', 'FastAPI'],
    impact: '95% Accuracy in categorization',
    icon: Database,
    color: 'from-neon-purple to-pink-500'
  },
  {
    title: 'Autonomous QA Agent',
    description: 'A self-healing test automation agent that identifies UI changes and updates test scripts automatically using computer vision.',
    tech: ['Playwright', 'TensorFlow.js', 'TypeScript'],
    impact: '60% Reduction in maintenance',
    icon: Layers,
    color: 'from-neon-green to-emerald-500'
  }
];

export const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col items-center mb-16"
        >
          <div className="flex items-center gap-2 text-neon-cyan font-mono text-sm uppercase tracking-[0.3em] mb-4">
            <Layers className="w-4 h-4" />
            Project Modules
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-center">Automation Deployments</h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, idx) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ y: -10 }}
              className="glass rounded-3xl overflow-hidden border border-white/5 hover:border-neon-blue/30 transition-all group"
            >
              <div className={cn("h-48 relative overflow-hidden bg-gradient-to-br", project.color)}>
                <div className="absolute inset-0 bg-black/20" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <project.icon className="w-20 h-20 text-white/20 group-hover:scale-110 transition-transform duration-500" />
                </div>
                {/* Animated data lines inside card header */}
                <div className="absolute inset-0 opacity-30 pointer-events-none">
                  <motion.div
                    animate={{ x: ['-100%', '100%'] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    className="absolute top-1/4 left-0 w-full h-px bg-white"
                  />
                  <motion.div
                    animate={{ x: ['100%', '-100%'] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                    className="absolute top-2/4 left-0 w-full h-px bg-white"
                  />
                </div>
              </div>

              <div className="p-8">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-bold leading-tight group-hover:text-neon-blue transition-colors">{project.title}</h3>
                  <div className="flex gap-2">
                    <button className="p-2 rounded-lg bg-white/5 hover:bg-neon-blue/20 transition-colors">
                      <Github className="w-4 h-4" />
                    </button>
                    <button className="p-2 rounded-lg bg-white/5 hover:bg-neon-blue/20 transition-colors">
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-sm text-white/60 mb-6 line-clamp-3">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tech.map(t => (
                    <span key={t} className="px-2 py-1 rounded-md bg-white/5 border border-white/10 text-[10px] font-mono uppercase tracking-tighter text-white/80">
                      {t}
                    </span>
                  ))}
                </div>

                <div className="pt-6 border-t border-white/5 flex items-center justify-between">
                  <div className="text-[10px] font-mono text-neon-green uppercase tracking-widest">Impact</div>
                  <div className="text-sm font-bold text-neon-green">{project.impact}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
