import React from 'react';
import { motion } from 'motion/react';
import { ChevronRight, Play, Bot, Zap, ShieldCheck } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-blue/10 border border-neon-blue/20 text-neon-blue text-xs font-bold tracking-widest uppercase mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neon-blue opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-neon-blue"></span>
            </span>
            System Online: AI Automation Core
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
            AI <span className="text-neon-blue">Automation</span> <br />
            Engineer
          </h1>
          
          <p className="text-lg md:text-xl text-white/60 max-w-xl mb-8 leading-relaxed">
            Building Intelligent Workflows, AI Systems & Scalable Automation. 
            <span className="text-white"> Automating the Future with AI Agents & Smart Systems.</span>
          </p>

          <div className="flex flex-wrap gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 rounded-xl bg-neon-blue text-dark-bg font-bold flex items-center gap-2 shadow-[0_0_20px_rgba(0,242,255,0.4)] hover:shadow-[0_0_30px_rgba(0,242,255,0.6)] transition-all"
            >
              View Projects <ChevronRight className="w-5 h-5" />
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 rounded-xl border border-white/10 bg-white/5 backdrop-blur-md font-bold flex items-center gap-2 hover:bg-white/10 transition-all"
            >
              Contact Me <Play className="w-4 h-4 fill-current" />
            </motion.button>
          </div>

          <div className="mt-12 flex items-center gap-8 text-white/40">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-neon-blue" />
              <span className="text-sm font-mono uppercase tracking-tighter">AI Agents</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-neon-purple" />
              <span className="text-sm font-mono uppercase tracking-tighter">Workflows</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-neon-green" />
              <span className="text-sm font-mono uppercase tracking-tighter">QA Automation</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative flex justify-center items-center"
        >
          {/* Animated AI Core Visualization */}
          <div className="relative w-72 h-72 md:w-96 md:h-96">
            {/* Outer Ring */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 border-2 border-dashed border-neon-blue/20 rounded-full"
            />
            {/* Middle Ring */}
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              className="absolute inset-8 border border-neon-purple/30 rounded-full flex items-center justify-center"
            >
               <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-4 bg-neon-purple rounded-full shadow-[0_0_15px_#bc13fe]" />
            </motion.div>
            {/* Inner Core */}
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                boxShadow: [
                  "0 0 20px rgba(0, 242, 255, 0.3)",
                  "0 0 50px rgba(0, 242, 255, 0.6)",
                  "0 0 20px rgba(0, 242, 255, 0.3)"
                ]
              }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute inset-20 bg-gradient-to-br from-neon-blue to-neon-purple rounded-full flex items-center justify-center overflow-hidden"
            >
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
              <Bot className="w-16 h-16 text-white drop-shadow-lg" />
            </motion.div>

            {/* Orbiting Nodes */}
            {[0, 72, 144, 216, 288].map((angle, i) => (
              <motion.div
                key={i}
                animate={{ rotate: 360 }}
                transition={{ duration: 10 + i * 2, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0"
              >
                <div 
                  className="absolute w-3 h-3 bg-neon-cyan rounded-full shadow-[0_0_10px_#00ffff]" 
                  style={{ 
                    top: '50%', 
                    left: '100%', 
                    transform: 'translate(-50%, -50%)' 
                  }} 
                />
              </motion.div>
            ))}
          </div>

          {/* Floating Data Panels */}
          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="absolute -top-10 -right-10 glass p-4 rounded-xl border-neon-blue/30 hidden md:block"
          >
            <div className="text-[10px] font-mono text-neon-blue mb-2 uppercase tracking-widest">System Status</div>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(i => (
                <motion.div 
                  key={i}
                  animate={{ height: [10, 20, 10] }}
                  transition={{ duration: 0.5, delay: i * 0.1, repeat: Infinity }}
                  className="w-1 bg-neon-blue rounded-full"
                />
              ))}
            </div>
          </motion.div>

          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="absolute -bottom-10 -left-10 glass p-4 rounded-xl border-neon-purple/30 hidden md:block"
          >
            <div className="text-[10px] font-mono text-neon-purple mb-1 uppercase tracking-widest">Neural Link</div>
            <div className="text-xs font-bold">ACTIVE_SYNC: 98%</div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};
